# SimpleIPTVRoku (Português BraSil)
A Basic Roku channel for watching IPTV on the Roku

This was forked from sudo97 
Added a few more containers to play mp4 mkv etc 

You need to enter developer mode on Roku to sideload the channel a detailed tutorial can be found here 
https://www.howtogeek.com/290787/how-to-enable-developer-mode-and-sideload-roku-apps/

There is a default playlist with (Mano TV - PT-BR). You can edit the m3u with your own or your iptv providers.

Wait ~30 secs on black screen is normal. It's annoying, i know, but the ManoTV list is very long and takes a long time to load. I'm thinking of a solution for this right now...

* Sort into sections
* The playlist window doesn't open on startup. To open it, press :arrow_backward: to display the channel list and press :eight_spoked_asterisk:
* Find channel pressing Counterclockwise arrow button. Forked: https://github.com/Kasmaristo-Delvakto/SimpleIPTVRoku
